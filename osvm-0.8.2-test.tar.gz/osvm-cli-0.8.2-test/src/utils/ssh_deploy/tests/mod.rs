//! Tests for SSH deployment

// Module declarations
mod e2e;
mod unit;
