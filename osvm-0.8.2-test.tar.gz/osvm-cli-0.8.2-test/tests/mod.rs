//! Test modules for OSVM CLI

pub mod e2e;
