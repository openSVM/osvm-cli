//! Main test file for OSVM CLI

// Include the test modules
mod e2e;
