// This file is no longer needed as its functionality has been moved to common.rs
// You can safely delete this file once you've confirmed common.rs has all the required functionality
